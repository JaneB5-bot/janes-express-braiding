JANES EXPRESS BRAIDING — FREE WEBSITE STARTER

This folder is a real, mobile-friendly website (not just an image).

Quickest free way to publish:
1. Create a free GitHub account at https://github.com
2. Create a new PUBLIC repository named janes-express-braiding
3. Upload index.html and the images folder.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch", select main and / (root), then Save.
6. GitHub will give you a public website link.

Before publishing, replace the placeholder text and photos with your real business information and hairstyle photos.

The current appointment form is only a starter. For a reliable free booking form, create a Google Form and replace the booking section/button with its link.
